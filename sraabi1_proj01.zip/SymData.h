/**
 * Describes a character-frequency pair
 * @author Duncan <br>
 * <pre>
 * Date: 99-99-9999
 * Course: csc 3102
 * Project: # 1
 * Instructor: Dr. Duncan
 * </pre>
 */
 
#include <string>
#include <cstdlib>
#include <iostream>
#include <exception>


using namespace std;

#ifndef SYMDATA_H
#define	SYMDATA_H


class SymData
{
private:
   /**
    * the symbol
    */
   char symbol;
   /**
    * the frequency of the symbol
    */
   int frequency;
   /**
    * the codeword for the symbol
    */
   string code;
   /**
    * a pointer to the left SymData object 
    */
   SymData* left;
   /**
    * a pointer to the right SymData object 
    */
   SymData* right;
   
public:
   /**
    * Creates an instance of this class
    * @param ch the symbol, a character 
    * @param f the frequency of the symbol 
    * @param cd the code for the symbol
    * @param lft a pointer to the SymData object representing
    * its left child.
    * @param rgt a pointer to the SymData object representing
    * its right child.
    */
   SymData(char ch, int f, string cd, SymData* lft, SymData* rgt);
   
   /**
    * returns the symbol
    * @return the symbol
    */
   char getSymb() const;
   
   /**
    * gives the frequency of the symbol
    * @return the frequency of the symbol
    */
   int getFreq() const;
   
   /**
    * gives the code for the symbol
    * @return the code for the symbol
    */
   string getCode() const;
   
   /**
    * gives the left SymData object of this object
    * @return the SymData that is a left child of this object
    */
   SymData* getLeft() const;
   
   /**
    * gives the right SymData object of this object
    * @return the SymData that is a right child of this object
    */
   SymData* getRight() const;
   
   /**
    * gives the symbol data in the format symbol, frequency, code
    * @return a string representation of this symbol data in the format 
    * symbol,frequency,code
    */
   string str() const;
    
   /**
    * Sets the code of this Object
    * @param cd the new code 
    */
   void setCode(string cd); 
   
   /**
    * Determines whether two SymData objects are equivalent
    * @param s1 a SymData object
    * @param s2 a SymData object
    * @return true when the specified SymData are equal, the 
    * same symbol; otherwise, false.
    */
   friend bool operator==(const SymData& s1, const SymData& s2);
   
   /**
    * Determines whether two SymData objects are not equivalent
    * @param s1 a SymData object
    * @param s2 a SymData object
    * @return true when the specified SymData are not equal, their 
    * symbols are different; otherwise, false.
    */
   friend bool operator!=(const SymData& s1, const SymData& s2);
   
   /**
    * Determines whether one SymData object comes after another
    * @param s1 a SymData object
    * @param s2 a SymData object
    * @return true when the first SymData comes after the second,
    * the symbol of the first comes after the second in 
    * lexicographical order; otherwise, false.
    */
   friend bool operator>(const SymData& s1, const SymData& s2);
   
   /**
    * Determines whether one SymData object comes before another
    * @param s1 a SymData object
    * @param s2 a SymData object
    * @return true when the first SymData comes before the second,
    * the symbol of the first comes before the second in 
    * lexicographical order; otherwise, false.
    */
   friend bool operator<(const SymData& s1, const SymData& s2);
   
   /**
    * Determines whether one SymData object is the same as or comes 
    * after another
    * @param s1 a SymData object
    * @param s2 a SymData object
    * @return true when the first SymData is the same as or comes after 
    * the second, the symbol of the first is the same as or comes after 
    * the second in lexicographical order; otherwise, false.
    */
   friend bool operator>=(const SymData& s1, const SymData& s2);
   
   /**
    * Determines whether one SymData object is the same as or comes 
    * before another
    * @param s1 a SymData object
    * @param s2 a SymData object
    * @return true when the first SymData is the same as or comes before 
    * the second, the symbol of the first is the same as or comes before
    * the second in lexicographical order; otherwise, false.
    */
   friend bool operator<=(const SymData& s1, const SymData& s2);
};
#endif	/* SYMDATA_H */

