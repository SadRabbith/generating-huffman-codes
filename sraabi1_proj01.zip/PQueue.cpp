/**
 * implementation file for the  min-priority queue class
 * that uses an STL vector as its container
 * @author William Duncan, YOUR NAME
 * <pre>
 * Date: 09/30/2024
 * Instructor: Dr. Duncan
 * Programming Project: 1
 * Course: csc 3102
 * </pre>
*/

#include "PQueue.h"

using namespace std;

template <typename E>
PQueue<E>::PQueue()
{
   //implement this function
	tree = std::vector<E>();

}

template <typename E>
PQueue<E>::PQueue(const PQueue<E>& pQ)
{
   //implement this function
	tree = pQ.tree;
	cmp = pQ.cmp;

}

template <typename E>
PQueue<E>::PQueue(std::function<bool(const E&, const E&)> fn)
{
   //implement this function
	tree.push_back(E());
	cmp = [](const E& a, const E& b) { return a < b; }; //compares in reverse order to get the greater than value
}

template <typename E>
bool PQueue<E>::isEmpty() const
{
   // implement this function
	return tree.empty();
}
// max-heap structure
template<typename E>
void PQueue<E>::insert(E item)
{
   //implement this function
	tree.push_back(item); //adds item
	int child = tree.size() - 1;
	int parent = (child - 1) / 2;
	while(parent >= 0 && cmp(tree[parent],tree[child])){
		swap(parent,child);
		child = parent;
		parent = (child - 1)/2;
		}
}

/*
template<typename E>
void PQueue<E>::insert(E item)
{
    // Add the new item to the end of the tree
    tree.push_back(item); // Adds item
    int child = tree.size() - 1; // Index of the newly added item
    int parent = (child - 1) / 2; // Index of the parent

    // Bubble up the new item to maintain the min-heap property
    while (parent >= 0 && cmp(tree[child], tree[parent])) {
        swap(child, parent); // Swap if the child is less than the parent
        child = parent; // Move down to the parent
        parent = (child - 1) / 2; // Update the parent index
    }
}
*/

template<typename E>
E PQueue<E>::remove()
{
    if (isEmpty()) {
        throw PQueueException("Queue is empty");
    }

    // Save the root (min or max element)
    E top = tree[0];

    // Move the last element to the root
    tree[0] = tree.back();
    tree.pop_back();  // Remove the last element

    // Rebuild the heap from the root (index 0)
    if (!isEmpty()) {
        rebuild(0);
    }

    return top;  // Return the removed element (former root)
}


template<typename E>
const E& PQueue<E>::peek() const
{
   //implement this function
	if(isEmpty()== true){
		throw PQueueException("Queue is empty");
	}
	return tree[0];
   //return nullptr;
}

template<typename E>
int PQueue<E>::size()const
{
   //Implement this function

   return tree.size()-1; //accounts for the dummy element at 0
}


template<typename E>
//void PQueue<E>::swap(int place, int parent)
void PQueue<E>::swap(int place, int parent)
{
   //implement this function
	std::swap(tree[place], tree[parent]);

}

// PQueue.cpp



// this is max heap
template<typename E>
void PQueue<E>::rebuild(int root)
{
    // Calculate the left child
    int child = 2 * root + 1;

    // Ensure that the left child exists
    if (child < tree.size()) {

        // Check if the right child exists and is greater (or lesser depending on heap type)
        if (child + 1 < tree.size() && cmp(tree[child], tree[child + 1])) {
            child = child + 1;  // Select the right child
        }

        // If the current root violates the heap property, swap it with the larger (or smaller) child
        if (cmp(tree[root], tree[child])) {
            swap(root, child);  // Swap root with the appropriate child

            // Recursively call rebuild on the swapped child to ensure the subheap is valid
            rebuild(child);
        }
    }


}

/*
template<typename E>
void PQueue<E>::rebuild(int root)
{
    // Calculate the left child
    int child = 2 * root + 1;

    // Ensure that the left child exists
    if (child < tree.size()) {
        // Check if the right child exists and is smaller (for min heap)
        if (child + 1 < tree.size() && cmp(tree[child + 1], tree[child])) {
            child = child + 1;  // Select the right child if it is smaller
        }

        // If the current root violates the heap property, swap it with the smaller child
        if (cmp(tree[child], tree[root])) {
            swap(root, child);  // Swap root with the appropriate child

            // Recursively call rebuild on the swapped child to ensure the subheap is valid
            rebuild(child);
        }
    }
*/




