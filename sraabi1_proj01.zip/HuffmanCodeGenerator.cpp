/**
 * A program that test the PQueueADT implementation by using
 * it to generate Huffman binary codes for a set of
 * character-frequency pairs.
 * @author Duncan, Sadman Sobhan Raabith
 * @see SymData.h, PQueue.h
 * <pre>
 * Date: 09/30/24
 * Course: csc 3102
 * Programming Project: 1
 * Instructor: Dr. Duncan
 * </pre>
 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <functional>
#include <vector>
#include <iomanip>
#include "PQueue.cpp"
#include "SymData.h"
#include<algorithm>

using namespace std;

vector<SymData*> genTable(vector<SymData*> codeList)
{
    // Sort alphabetically by symbol (a to f)
    stable_sort(codeList.begin(), codeList.end(),
         [](const SymData* a, const SymData* b) {
             // Changed comparison to ensure a to f ordering
             return a->getSymb() < b->getSymb();
         });

    // Print the formatted table
    cout << left << setw(8) << "Symbol"
         << left << setw(12) << "Frequency"
         << "Codeword" << endl;
    cout << string(30, '-') << endl;

    for (const auto& sym : codeList) {
        cout << left << setw(8) << sym->getSymb()
             << left << setw(12) << sym->getFreq()
             << sym->getCode() << endl;
    }

    return codeList;
}
/*
void genTableReversed(const vector<SymData*>& codeList)
{
    // Print the formatted table header
    cout << left << setw(8) << "Symbol"
         << left << setw(12) << "Frequency"
         << "Codeword" << endl;
    cout << string(30, '-') << endl;

    // Print the elements in reverse order
    for (auto it = codeList.rbegin(); it != codeList.rend(); ++it) {
        const SymData* sym = *it; // Dereference the iterator
        cout << left << setw(8) << sym->getSymb()
             << left << setw(12) << sym->getFreq()
             << sym->getCode() << endl;
    }
}
*/
vector<SymData*> genHuffCodes(SymData* root) {
    vector<SymData*> codeList;
    vector<SymData*> stack;
    SymData* cur;

    stack.push_back(root);

    while(!stack.empty()){
    	cur = stack.back();
    	if(cur->getLeft()){
    		cur-> getLeft() ->setCode(cur->getCode()+"0");
    		stack.push_back(cur->getLeft());
    	}
    	if(cur->getRight()){
    		cur->getRight()->setCode(cur->getCode()+"1");
    		codeList.push_back(cur->getRight());

    	}
    	delete stack[0];
    }
    return codeList;

}


SymData* genHuffTree(PQueue<SymData*> huffForest) {
	SymData* left;
	SymData*right;
    while (huffForest.size() > 1) {
        cout << "Current forest size: " << huffForest.size() << endl;


        left = huffForest.remove();
        cout << "Removed left node: " << left->getSymb() << endl;

        right = huffForest.remove();
        cout << "Removed right node: " << right->getSymb() << endl;

        int combinedFreq = left->getFreq() + right->getFreq();
        cout << "Combining nodes: " << left->getSymb() << "(" << left->getFreq() << ") and "
             << right->getSymb() << "(" << right->getFreq() << ") = " << combinedFreq << endl;

        SymData* combinedNode = new SymData('\0', (left->getFreq())+(right->getFreq())," ", left, right);
        huffForest.insert(combinedNode);
    }

    cout << "Huffman tree generated" << endl;
    return huffForest.remove(); //returns the root of the Huffman tree
}


int main(int argc, char** argv)
{


    string usage = "HuffmanCodeGenerator <data-file-name>\n";
    usage += "The data file name is entered as a command line argumet.\n";
    usage += "The data file contains two columns per row.\n";
    usage += "Each row has a symbol (char) and frequency pair.";
    if (argc != 2)
    {
        cout << "Invalid number of command line arguments" << endl;
        cout << usage << endl;
        exit(1);
    }
    try {
        cout << "Opening file: " << argv[1] << endl;
        ifstream inputFile(argv[1]);
        if (!inputFile.is_open()) {
            throw PQueueException("Error opening file.");
        }
        cout << "File opened successfully" << endl;

        PQueue<SymData*> huffForest([](SymData* s1, SymData* s2) {
            cout << "Comparing: " << s1->getSymb() << "(" << s1->getFreq() << ") and "
                 << s2->getSymb() << "(" << s2->getFreq() << ")" << endl;
            bool result = s1->getFreq() < s2->getFreq() || (s1->getFreq() == s2->getFreq() && s1->getSymb() < s2->getSymb());
            cout << "Comparison result: " << (result ? "true" : "false") << endl;
            return result;
        });

        char symbol;
        int frequency;
        cout << "Reading file contents:" << endl;
        while (inputFile >> symbol >> frequency) {
            cout << "Read: " << symbol << " " << frequency << endl;
            SymData* node = new SymData(symbol, frequency, "", nullptr, nullptr);
            cout << "Created SymData: symbol = " << node->getSymb() << ", frequency = " << node->getFreq() << endl;
            huffForest.insert(node);
        }



        inputFile.close();

        cout << "Huffman forest size: " << huffForest.size() << endl;

        cout << "Generating Huffman Tree" << endl;
        SymData* huffRoot = genHuffTree(huffForest);

        cout << "Generating Huffman Codes" << endl;
        vector<SymData*> huffCodes = genHuffCodes(huffRoot);

        cout << "Number of Huffman codes generated: " << huffCodes.size() << endl;

        cout << "Generating and sorting table" << endl;
        vector<SymData*> sortedTable = genTable(huffCodes);
        //genTableReversed(sortedTable);

        cout << "Sorted table size: " << sortedTable.size() << endl;

        cout << left << setw(10) << "Symbol" << setw(15) << "Frequency" << setw(20) << "Codeword" << endl;
        for (SymData* code : sortedTable) {
            cout << left << setw(10) << code->getSymb() << setw(15) << code->getFreq() << setw(20) << code->getCode() << endl;
        }
    }
    catch(const PQueueException& e)
    {
        cout << e.what() << endl;
    }
    catch(const std::exception& e)
    {
        cout << "Standard exception: " << e.what() << endl;
    }
    catch(...)
    {
        cout << "Unknown error occurred" << endl;
    }
    return 0;


/*
	// Define the maxheap comparator (greater-than behavior)
	std::function<bool(const int&, const int&)> maxheap = [](const int& a, const int& b) {
		return !(a < b);  // This will create a max-heap, the opposite of the default min-heap
		};
	PQueue<int> nums(maxheap);
	nums.insert(9);
	nums.insert(8);
	nums.insert(5);
	nums.insert(3);
	nums.insert(15);
	nums.insert(2);

	while(nums.size()>0){
		cout<<nums.remove()<<endl;
	}
	*/

}
