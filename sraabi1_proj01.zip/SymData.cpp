/**
 * Implementation file for the SymData class.
 * @author Duncan <br>
 * @see SymData.h
 * <pre>
 * Date: 99-99-9999
 * Course: csc 3102
 * Programming Project: 1
 * Instructor: Dr. Duncan
 * </pre>
 */

#include <sstream>
#include "SymData.h"

SymData::SymData(char ch, int f, string cd, SymData* lft, SymData* rgt)
{
   symbol = ch; frequency = f; code = cd;
   left = lft; right = rgt;
}
    
char SymData::getSymb() const
{
   return symbol;
}
   
int SymData::getFreq() const
{
   return frequency;
}

string SymData::getCode() const
{
   return code;
}
   
SymData* SymData::getLeft() const
{
   return left;
}
   
SymData* SymData::getRight() const
{
   return right;
}
   
string SymData::str() const
{
   stringstream sout;
   sout<<symbol<<", "<<frequency<<", "<<code;
   return sout.str();
}
    
void SymData::setCode(string cd)
{
   code = cd;
}

bool operator==(const SymData& s1, const SymData& s2)
{ 
   return s1.symbol == s2.symbol;
}   

bool operator!=(const SymData& s1, const SymData& s2)
{   
   return !(s1 == s2);
}   

bool operator>(const SymData& s1, const SymData& s2)
{   
   return s1.symbol > s2.symbol;
}   

bool operator<(const SymData& s1, const SymData& s2)
{   
   return (s1 != s2) && !(s1 > s2);
}   

bool operator<=(const SymData& s1, const SymData& s2)
{   
   return (s1 < s2) || (s1 == s2);
}   

bool operator>=(const SymData& s1, const SymData& s2)
{   
   return (s1 > s2) || (s1 == s2);
}   
